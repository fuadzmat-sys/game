"""Build the Russian-only Chapter 4, leaving every released story resource intact."""
from pathlib import Path
import json,re,hashlib,subprocess
ROOT=Path(__file__).resolve().parents[1]
NS='chapter_4/'
ORDER=['start','bag_authority','bag_reason','bag_irony','passage','captive','search','search_tracks','search_pattern','search_terrain','captive_two','ravine','rendezvous','rescue_ledge','rescue_anchor','rescue_signal','return','road']
MAIN=['start','passage','captive','search','captive_two','ravine','rendezvous','return','road']
CHOICES={
 'start':('bag_method',[('Authority','bag_authority','Настоять на передаче сумки'),('Reason','bag_reason','Объяснить, зачем разделить задачи'),('Irony','bag_irony','Ответить Венди колкостью')],'passage'),
 'search':('search_method',[('Tracks','search_tracks','Проверить физические следы'),('Pattern','search_pattern','Восстановить поведение вендиго'),('Terrain','search_terrain','Доверить Венди выбор обхода')],'captive_two'),
 'rendezvous':('rescue_plan',[('Ledge','rescue_ledge','Вывести Пасифику по сухому уступу'),('Anchor','rescue_anchor','Закрепить страховочный ремень'),('Signal','rescue_signal','Двигаться по сигналу Пасифики')],'return')}
NEXT={'passage':'captive','captive':'search','captive_two':'ravine','ravine':'rendezvous','return':'road'}
SELECTORS={}
for scene,(key,options,rejoin) in CHOICES.items():
 for value,target,_ in options:NEXT[target]=rejoin;SELECTORS[target]=(key,value)
PAIR=['char showi Gideon left scale .8','char showi Wendy right flip left scale 1.08']
TRIO=['char showi Gideon left scale .8','char showi Pacifica center flip left scale 1','char showi Wendy right flip left scale 1.08']
RESET=['item hide','effect clear','fx clear','camera preset normal duration .8']
HIDE=['char hidei Pacifica Gideon Wendy Wendigo Creature Predator Dog SmallDog Cat Will Mabel Dipper Mothman']
STAGING={
 'start':['scene chapter_4']+HIDE+RESET+['BG change ch3_lumber_yard time .8','music stop fade .7','ambience forest_tension','fx dark_vignette']+TRIO+['expression Pacifica curious transition .2','expression Gideon upset transition .2','expression Wendy annoyed transition .2'],
 'passage':RESET+['BG change forest_1_dusk time 1.2','music curious fade .8','ambience forest_tension','fx forest_wind']+TRIO,
 'captive':HIDE+RESET+['BG change ch4_ravine time 1.1','music stop fade .3','ambience forest_tension','fx dark_vignette','char showi Pacifica left scale 1','expression Pacifica scared transition 0','char showi Wendigo right flip left scale .85'],
 'search':HIDE+RESET+['BG change ch1_deep_forest time 1.1','music stop fade .8','ambience forest_tension','fx forest_wind']+PAIR+['expression Gideon annoyed_obvious transition 0','expression Wendy annoyed transition .2'],
 'captive_two':HIDE+RESET+['BG change ch4_ravine time 1.1','music curious fade .8','ambience forest_tension','fx dark_vignette','char showi Pacifica left scale 1','expression Pacifica upset transition .2','char showi Wendigo right flip left scale .85'],
 'ravine':HIDE+RESET+['BG change ch4_ravine time 1.1','music stop fade .6','ambience forest_tension','fx forest_wind']+PAIR+['expression Gideon upset transition .2','expression Wendy upset transition .2'],
 'rendezvous':HIDE+RESET+['BG change ch4_ravine time 1','music curious fade 1','ambience forest_tension','fx dark_vignette']+TRIO+['expression Pacifica scared transition .2','expression Gideon upset transition .2','expression Wendy upset transition .2'],
 'return':RESET+['BG change ch4_ravine time 1','music stop fade 1','ambience forest_tension','fx dark_vignette']+TRIO+['expression Gideon upset transition .2','expression Pacifica upset transition .2','expression Wendy upset transition .2'],
 'road':HIDE+RESET+['BG change ch1_road time 1.6','music forest_day_1 fade 1.4','ambience forest_day','fx forest_wind']+TRIO+['expression Pacifica upset transition .2','expression Gideon upset transition .2','expression Wendy annoyed transition .2']}
CUES={
 'silence':['music stop fade .8','wait .45'],
 'p_back':['anim Pacifica step_back'],
 'transfer':['anim Wendy step_back','anim Pacifica step_forward','sfx ch2_wood_creak','wait .35'],
 'reveal':['music stop fade .3','char show Wendigo right from outright duration 1.1 scale .85','expression Pacifica scared transition .15','expression Gideon surprised transition .15','anim Pacifica recoil','camera zoom 1.035 duration 1.2','wait .4'],
 'abduction':['sfx branch_crack','anim Pacifica recoil','anim Gideon step_forward','camera shake small duration .2','char hide Pacifica to outright duration .3','char hide Wendigo to outright duration .4','wait .35'],
 'after_abduction':['music stop fade 0','ambience stop','expression Gideon scared transition 0','anim Gideon step_forward','wait .7','ambience forest_tension'],
 'p_fear':['expression Pacifica scared transition 0','anim Pacifica recoil','camera zoom 1.03 duration 1.2','wait .45'],
 'bag_down':['anim Pacifica step_back','sfx ch2_wood_creak'],
 'p_resolve':['expression Pacifica fighting transition .3','anim Pacifica step_forward'],
 'search_tense':['camera zoom 1.025 duration 1','anim Gideon step_forward'],
 'snap':['expression Gideon annoyed_obvious transition .12','anim Gideon step_forward','expression Wendy upset transition .15','wait .6'],
 'captivity_shift':['sfx ch2_wood_creak','anim Pacifica step_back'],
 'amulet':['item show ch3_wooden_weight','camera zoom 1.035 duration 1','wait .35','item hide'],
 'p_flinch':['anim Pacifica recoil','expression Pacifica scared transition .1','sfx impact','camera shake small duration .16'],
 'three_knocks':['sfx ch2_wood_creak','wait .25','sfx ch2_wood_creak','wait .25','sfx ch2_wood_creak','wait .5'],
 'collapse':['sfx branch_crack','anim Wendy recoil','anim Gideon step_forward','expression Wendy upset transition .1','camera shake small duration .22','wait .35'],
 'save_wendy':['anim Gideon lean_forward','anim Wendy step_forward','sfx ch2_wood_creak','wait .35'],
 'respect_pause':['expression Wendy upset transition .2','expression Gideon upset transition .2','camera preset medium duration 1.1','wait .6'],
 'reunion_view':['camera zoom 1.03 duration 1','expression Gideon surprised transition .2','expression Pacifica upset transition .2','wait .6'],
 'rescue_still':['music stop fade .5','wait .6'],
 'return_approach':['char hide Gideon to outleft duration .6','char hide Pacifica to outleft duration .7','char move Wendy left duration .7','char show Wendigo right from outright duration .9 scale .85','anim Wendy step_back'],
 'amulet_returned':['item show ch3_wooden_weight','wait .5','item hide','char hide Wendigo to outright duration 1.3','fx clear','ambience forest_day','camera preset normal duration 1.5','wait .5'],
 'relief':['camera preset normal duration 1.2','anim Pacifica sad_drop','wait .4']}
EMOTIONS={
 'Pacifica':{'neutral':'idle','confident':'smile_aggressive','annoyed':'annoyed','amused':'laugh','suspicious':'curious','focused':'curious','curious':'curious','surprised':'surprised','worried':'upset','afraid':'scared','embarrassed':'embarrassed','serious':'fighting','relieved':'smile','small_smile':'smile'},
 'Gideon':{'neutral':'idle','deadpan':'idle','amused':'smile','annoyed':'annoyed','focused':'idle','worried':'upset','afraid':'scared','surprised':'surprised','serious':'idle','stressed':'annoyed_obvious','angry':'annoyed_obvious'},
 'Wendy':{'neutral':'idle','smug':'idle','amused':'idle','annoyed':'annoyed','suspicious':'annoyed','surprised':'upset','defensive':'annoyed','serious':'upset','stressed':'upset','afraid':'upset','embarrassed':'embarrassed'}}
SPEAKERS={'N':'Narrator','P':'Pacifica','G':'Gideon','W':'Wendy'}
ACTING={'Pacifica':{'annoyed':'step_forward','surprised':'recoil','afraid':'step_back','relieved':'sad_drop','amused':'lean_forward'},'Gideon':{'angry':'step_forward','afraid':'recoil','surprised':'step_back'},'Wendy':{'smug':'lean_forward','surprised':'step_back','embarrassed':'sad_drop'}}
def command(s):return '['+s+']'
def build():
 rows={};current=None;pending=[]
 for line in (ROOT/'tools/chapter4-story.txt').read_text().splitlines():
  if not line:continue
  if line.startswith('# '):current=line[2:];assert current not in rows;rows[current]=[];continue
  if line.startswith('@'):pending+=CUES[line[1:]];continue
  actor,text=line.split(' ',1);actor,_,condition=actor.partition('?');actor,_,emotion=actor.partition('.');speaker=SPEAKERS[actor]
  assert not any(c in text for c in ['[',']','\n'])
  rows[current].append({'speaker':speaker,'ru':text,'emotion':emotion,'commands':pending,'when':condition});pending=[]
 assert set(rows)==set(ORDER)
 wrapped=subprocess.run(["node",str(ROOT/"tools/layout-chapter4.mjs")],input=json.dumps(rows,ensure_ascii=False),text=True,capture_output=True,check=True)
 rows=json.loads(wrapped.stdout)
 scripts={};slots=[];wordcount=0
 selected=json.loads((ROOT/'assets/selected-voices/manifest.json').read_text())
 references={v['characterId']:v for v in selected['voices']}
 for name in ORDER:
  parts=[command(x) for x in STAGING.get(name,[])]
  if name in SELECTORS:
   key,value=SELECTORS[name];parts.insert(0,command(f'Choice {key} {value}'))
  emotions={};lastmove=-10
  for idx,row in enumerate(rows[name]):
   speaker=row['speaker'];emotion=row['emotion'];commands=list(row['commands'])
   if emotion:
    mapped=EMOTIONS[speaker][emotion]
    if emotions.get(speaker)!=mapped:
     commands.append(f'expression {speaker} {mapped} transition .2');emotions[speaker]=mapped
     # Sparse physical reactions with room for the stronger feeling to linger.
     if emotion in ACTING.get(speaker,{}) and idx-lastmove>=6:
      commands.append(f'anim {speaker} {ACTING[speaker][emotion]}');lastmove=idx
   
   if row.get('when'):
    flag,value=row['when'].split('=');parts.append(command(f'when {flag} {value}')+''.join(command(x) for x in commands)+command(speaker)+row['ru'])
   else:parts.extend(command(x) for x in commands);parts.extend([command(speaker),row['ru']])
   wordcount+=len(re.findall(r'[\w]+(?:[’-][\w]+)*',row['ru']))
  if name in CHOICES:
   parts+=['[item hide]','[Choice importance important]']
   for i,(_,target,label) in enumerate(CHOICES[name][1],1):parts+=[command(f'Button text {i} {label}'),command(f'Button order {i} next {NS}{target}')]
   parts+=['[stop]']
  elif name=='road':parts+=['[item hide]','[music stop fade 1.2]','[wait .6]','[stop]','[scene credits]']
  else:parts+=[command('next '+NS+NEXT[name])]
  resource='textes/russian/'+NS+name;scripts[resource]='\n\n'.join(parts)+'\n'
  speaker='Narrator'
  for line,text in enumerate(x for x in scripts[resource].splitlines() if x):
   if text in [command(x) for x in SPEAKERS.values()]:speaker=text[1:-1]
   tags=re.findall(r'\[([^\]]+)\]',text)
   for tag in tags:
    if tag in SPEAKERS.values():speaker=tag
   text=re.sub(r'\[[^\]]*\]','',text).strip()
   if not text:continue
   ref=references[speaker]
   slots.append({'key':f'russian|{NS}{name}|{line}|{speaker.lower()}','script':NS+name,'sourceLine':line,'speaker':speaker,'language':'russian','text':text,'status':'pending','selectedReference':ref['path'],'referenceSha256':ref['sha256']})
 (ROOT/'assets/chapter4-scripts.json').write_text(json.dumps(scripts,ensure_ascii=False,indent=2)+'\n')
 (ROOT/'assets/chapter4-voice-plan.json').write_text(json.dumps({'version':1,'namespace':NS,'allowSystemSpeech':False,'status':'approved-references-pending-line-recordings','lines':slots},ensure_ascii=False,indent=2)+'\n')
 defs=[];graphnodes=[];edges=[]
 labels={'start':'Чья теперь сумка','passage':'Следом за вещью','captive':'Под корнями','search':'Без Пасифики','captive_two':'Три удара','ravine':'Не оставлять','rendezvous':'С двух сторон','return':'Вернуть чужое','road':'Обычная дорога'}
 details={'start':'Пасифика выбирает, как добиться передачи сумки.','passage':'Перемещение предмета меняет цель преследования.','captive':'Пасифика наблюдает и оставляет след для поисков.','search':'Гидеон и Венди выбирают, что проверить первым.','captive_two':'Пасифика освобождает застёжку и подаёт сигнал.','ravine':'Гидеон помогает Венди выбраться с обрушившегося края.','rendezvous':'Выбрать совместный план выхода с полки.','return':'Венди сама возвращает амулет.','road':'Непосредственная угроза позади. Дружбы пока нет.'}
 effect=lambda t,k,v:{'type':t,'key':k,'value':v}
 knowledge=lambda k:[{'type':'knowledge','character':c,'key':k} for c in ['pacifica','gideon']]
 branch_effects={
 'Authority':[effect('flag','ch4_bag_guarded',True)],'Reason':[effect('relationship','wendy_respect',1)],'Irony':[],
 'Tracks':knowledge('ch4_carried_above_ground'),'Pattern':knowledge('ch4_amulet_target'),'Terrain':[effect('relationship','wendy_respect',1)],
 'Ledge':[effect('flag','ch4_marked_exit',True)],'Anchor':[effect('flag','ch4_wrist_strain',True)],'Signal':knowledge('ch4_pacifica_signal')}
 # Consequences remain sourced by decision IDs, as in Chapters 1–3.
 for scene,(key,options,rejoin) in CHOICES.items():
  entries=[]
  for value,target,label in options:
   effects=branch_effects[value].copy()
   if key=='rescue_plan':effects += [effect('relationship','wendy_respect',1),effect('relationship','pacifica_gideon',1)]
   entries.append({'id':value,'nodeId':target,'effects':effects})
  defs.append({'id':'ch4.'+key,'chapterId':4,'legacyKey':key,'sceneId':NS+scene,'dependsOn':[],'requirements':[],'rejoinNode':rejoin,'options':entries})
 cols={'start':0,'bag_authority':1,'bag_reason':1,'bag_irony':1,'passage':2,'captive':3,'search':4,'search_tracks':5,'search_pattern':5,'search_terrain':5,'captive_two':6,'ravine':7,'rendezvous':8,'rescue_ledge':9,'rescue_anchor':9,'rescue_signal':9,'return':10,'road':11}
 for name in ORDER:
  source=next(((scene,opt,label) for scene,(_,opts,_) in CHOICES.items() for opt,target,label in opts if target==name),None)
  label=source[2] if source else labels[name];desc=('Отдельная тактика; путь затем возвращается к общей сцене.' if source else details[name])
  graphnodes.append({'id':name,'x':100+cols[name]*570,'y':(220+next(i for i,x in enumerate(CHOICES[source[0]][1]) if x[0]==source[1])*320) if source else 540,'width':420,'height':155,'label':{'russian':label},'detail':{'russian':desc},'kind':'choice' if name in CHOICES else 'ending' if name=='road' else 'start' if name=='start' else 'event'})
  targets=[x[1] for x in CHOICES[name][1]] if name in CHOICES else [NEXT[name]] if name in NEXT else []
  for target in targets:edges.append({'id':name+'>'+target,'from':name,'to':target})
 # Match the existing graph's edge ID contract.
 for edge in edges:edge['id']=edge['from']+'>'+edge['to']
 graph={'chapter':4,'width':6900,'height':1280,'nodes':graphnodes,'edges':edges}
 module='// Generated from tools/build-chapter4.py; Russian-only story registration.\n'
 module+='export const CHAPTER4_CHOICES = '+json.dumps({key:[x[0] for x in opts] for key,opts,_ in CHOICES.values()},ensure_ascii=False)+';\n'
 module+='export const CHAPTER4_ENDINGS = '+json.dumps({value:{'title':{'russian':label}} for value,_,label in CHOICES['rendezvous'][1]},ensure_ascii=False)+';\n'
 module+='export const CHAPTER4_DECISIONS = '+json.dumps(defs,ensure_ascii=False)+';\n'
 module+='export const CHAPTER4_GRAPH = '+json.dumps(graph,ensure_ascii=False)+';\n'
 (ROOT/'chapter4.js').write_text(module)
 report={'resources':len(scripts),'scenes':len(MAIN),'choices':3,'counts':{'russian':{'words':wordcount,'paragraphs':sum(map(len,rows.values()))}},'voiceLines':len(slots),'language':'russian','plotArc':'Амулет возвращён Венди; непосредственная угроза завершена.'}
 assert 5500<=wordcount<=6500,report
 (ROOT/'assets/chapter4-build-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':build()
