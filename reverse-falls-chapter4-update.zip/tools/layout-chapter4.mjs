/** Use the shipped bitmap font to paginate only new Chapter 4 paragraphs. */
import fs from 'node:fs';
import { BitmapText } from '../bitmap-font.js';
const input=JSON.parse(fs.readFileSync(0,'utf8'));
const config=JSON.parse(fs.readFileSync(new URL('../assets/config.json',import.meta.url)));
const font=new BitmapText({},{});
for(const [name,source]of Object.entries(config.fonts))font.fonts.set(name,{name,info:source.info,glyphs:new Map(source.glyphs.map(g=>[g.id,g])),kerning:new Map(),atlas:{height:4096}});
const fits=text=>font.layout(text,{font:'AccentsRobotoMediumC',extendedGlyphs:true,size:124*.7,maxWidth:2276}).height+6<=466;
function pages(text){
 if(fits(text))return[text];
 const result=[];let current='';
 for(const sentence of text.split(/(?<=[.!?…])\s+/u)){
  if(fits((current+' '+sentence).trim())){current=(current+' '+sentence).trim();continue;}
  if(current){result.push(current);current='';}
  if(fits(sentence)){current=sentence;continue;}
  // A rare long sentence is continued at the last clause that fits, then at a word.
  for(const clause of sentence.split(/(?<=[,;:])\s+/u)){
   if(fits((current+' '+clause).trim())){current=(current+' '+clause).trim();continue;}
   if(current){result.push(current);current='';}
   for(const word of clause.split(/\s+/u)){
    if(!fits((current+' '+word).trim())&&current){result.push(current);current='';}
    current=(current+' '+word).trim();
   }
  }
 }
 if(current)result.push(current);
 if(result.join(' ')!==text)throw Error('Pagination altered Chapter 4 text');
 if(!result.every(fits))throw Error('Unpageable Chapter 4 text');
 return result;
}
const wrapped=Object.fromEntries(Object.entries(input).map(([scene,rows])=>[scene,rows.flatMap(row=>pages(row.ru).map((ru,i)=>({...row,ru,commands:i?[]:row.commands,emotion:i?'':row.emotion}))) ]));
process.stdout.write(JSON.stringify(wrapped));
