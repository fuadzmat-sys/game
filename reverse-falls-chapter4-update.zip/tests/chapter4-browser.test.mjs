import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createRequire } from 'node:module';
const require=createRequire(import.meta.url);let chromium;try{({chromium}=require('playwright'));}catch{({chromium}=require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));}
const read=n=>JSON.parse(fs.readFileSync(new URL('../'+n,import.meta.url),'utf8'));
const supplied=read('все выровы с 0-3 главы.json');
const out=process.env.REVERSE_FALLS_SCREENSHOT_DIR||'/workspace/work/screenshots';fs.mkdirSync(out,{recursive:true});
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});
const errors=[],missing=[],warnings=[],report=[];
try{
 const context=await browser.newContext({viewport:{width:1440,height:900}});
 await context.addInitScript(()=>{localStorage.setItem('reverse-falls-preferences',JSON.stringify({language:'english',chapter:3,reducedMotion:true,speech:true}));window.__spoken=0;window.__played=[];const play=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){window.__played.push(this.src);return play.call(this);};if(window.speechSynthesis)window.speechSynthesis.speak=()=>window.__spoken++;});
 const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)missing.push(r.url());});page.on('console',m=>{if(m.type()==='warning')warnings.push(m.text());});
 await page.goto(process.env.REVERSE_FALLS_TEST_URL||'http://127.0.0.1:8780');await page.waitForFunction(()=>window.game?.story.isInitialized());
 assert.equal(await page.evaluate(()=>game.preferences.language),'russian');
 await page.evaluate(()=>game.openFlowchart());const chooser=page.waitForEvent('filechooser');await page.locator('#flow-import-save').click();await(await chooser).setFiles({name:'главы0-3.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(supplied))});await page.locator('#flow-import-confirm-accept').waitFor({state:'visible'});await page.locator('#flow-import-confirm-accept').click();await page.waitForFunction(()=>document.querySelector('#flow-import-confirm').hidden);
 await page.evaluate(()=>game.openChapters());assert.equal(await page.locator('#chapter4-start').isEnabled(),true);assert.ok(!(await page.locator('#chapter-picker').innerText()).includes('English'));await page.waitForTimeout(1800);await page.screenshot({path:out+'/chapter4-picker.png'});
 await page.locator('#chapter4-start').click();await page.waitForFunction(()=>game.engine.state.script==='chapter_4/start');
 const overflow=await page.evaluate(async()=>{const {BitmapText}=await import('./bitmap-font.js'),{parseLine}=await import('./engine.js');const d=window.REVERSE_FALLS_DATA,font=new BitmapText(d.config.fonts,d.manifest);await font.load();const bad=[];for(const [path,source]of Object.entries(d.scripts))if(path.startsWith('textes/russian/chapter_4/'))for(const line of source.split('\n')){const text=parseLine(line).text;if(!text.trim())continue;const l=font.layout(text,{font:'AccentsRobotoMediumC',extendedGlyphs:true,size:124*.7,maxWidth:2276});if(l.height+6>466)bad.push({path,text,height:l.height});}return bad;});assert.deepEqual(overflow,[]);
 async function drive(script,phase='dialogue'){
  return page.evaluate(async({script,phase})=>{
   if(!window.__realNow)window.__realNow=performance.now.bind(performance);let extra=0;performance.now=()=>window.__realNow()+(extra+=10000);
   let steps=0;const picks={'chapter_4/start':1,'chapter_4/search':2,'chapter_4/rendezvous':1};
   while(!(game.engine.state.script===script&&game.engine.state.phase===phase)&&game.engine.state.phase!=='credits'&&steps++<2500){if(game.engine.state.phase==='choice')game.choose(picks[game.engine.state.script]);else game.next();}
   performance.now=window.__realNow;
   if(game.engine.state.script!==script||game.engine.state.phase!==phase)throw Error('Missed '+script+' '+game.engine.state.phase);
   return steps;
  },{script,phase});
 }
 async function shot(name){await page.evaluate(()=>{game.save();game.load(4);});await page.waitForTimeout(1500);await page.waitForFunction(()=>[...document.querySelectorAll('#characters img')].filter(i=>!i.hidden).every(i=>i.complete&&i.naturalWidth>0)&&document.querySelector('#background').naturalWidth>0);await page.screenshot({path:out+'/chapter4-'+name+'.png'});}
 await drive('chapter_4/start','choice');await shot('bag-choice');
 await drive('chapter_4/captive');await shot('captivity');
 assert.ok(await page.locator('[data-character="wendigo"] .character-head').evaluate(i=>!i.hidden&&i.naturalWidth>0));
 assert.equal(await page.evaluate(()=>game.engine.state.chars.gideon?.visible),false);
 await page.evaluate(()=>game.save());const before=await page.evaluate(()=>({script:game.engine.state.script,line:game.engine.state.line,choices:game.story.getCanon().choices}));await page.reload();await page.waitForFunction(()=>window.game?.story.isInitialized());await page.evaluate(()=>game.load(4));assert.equal(await page.evaluate(()=>game.engine.state.script),before.script);assert.deepEqual(await page.evaluate(()=>game.story.getCanon().choices),before.choices);
 await drive('chapter_4/ravine');await shot('forced-partnership');
 // Open settings, verify the supplied Gideon reference is used verbatim and stops on close.
 await page.keyboard.press('Escape');await page.locator('#approved-voice-open').click();await page.locator('#approved-voice').waitFor({state:'visible'});assert.equal(await page.locator('#approved-voice option').count(),36);await page.locator('#approved-voice').selectOption('Gideon');await page.locator('#approved-voice-play').click();await page.waitForTimeout(200);assert.ok((await page.evaluate(()=>window.__played)).some(p=>p.includes('gideon9-more_audio_gideon9_all.mp3')));await page.screenshot({path:out+'/chapter4-voice-settings.png'});await page.locator('#approved-voice-close').click();await page.locator('#settings-close').click();
 await drive('chapter_4/rendezvous','choice');await shot('rescue-choice');
 await drive('chapter_4/road','credits');await page.waitForTimeout(500);assert.ok(await page.locator('#chapter-ending').isVisible());assert.equal(await page.locator('#ending-title').innerText(),'Вернуть чужое');assert.equal(await page.locator('#ending-next-chapter').isVisible(),false);await shot('ending');
 const canon=await page.evaluate(()=>game.story.getCanon());for(const [k,v]of Object.entries(supplied.canon.choices))assert.equal(canon.choices[k],v);assert.equal(canon.derived.quests.wendy_forest_object.value,'resolved');assert.equal(canon.derived.flags.ch4_wrist_strain.value,true);
 await page.evaluate(()=>game.openFlowchart());await page.locator('#flow-chapter4').click();await page.locator('#flow-full').click();await page.waitForTimeout(300);await page.screenshot({path:out+'/chapter4-flowchart.png'});assert.equal(await page.locator('[data-node="bag_authority"]').count()>0,true);
 assert.equal(await page.evaluate(()=>window.__spoken),0);
 assert.deepEqual(errors,[]);assert.deepEqual(missing,[]);
 report.push('Real 0–3 portable save import → Chapter 4 unlock → three choices → ending','Captivity save/reload retains actual choices','Russian paragraph layout: no overflow','36 approved references; exact Gideon sample playback','No browser TTS or unrelated voice clips','No page errors or missing assets');
 fs.writeFileSync(out+'/chapter4-browser-report.json',JSON.stringify({report,errors,missing,warnings},null,2));console.log(JSON.stringify({report,errors,missing,warnings},null,2));
}finally{await browser.close();}
