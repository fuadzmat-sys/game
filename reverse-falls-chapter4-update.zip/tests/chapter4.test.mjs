import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { StoryEngine, parseLine } from '../engine.js';
import { CHAPTERS, CHAPTER_IDS, chapterLanguage, chapterForSnapshot, markCompleted, readCampaign, validCampaign } from '../campaign.js';
import { CHAPTER4_CHOICES } from '../chapter4.js';
import { STORY_REGISTRY, seedChapterFlags, seedChapterInventory, reconcileSnapshot, choicesFromSnapshot, progressFromSnapshot, createCanonicalFlowJump, rebuildSnapshotsForRewrite } from '../story-bridge.js';
import { createStoryEnvelope, createStoryStateService } from '../story-state.js';
import { getFlowGraph } from '../flowchart.js';
import { buildCanonTimeline } from '../canon-timeline.js';
import { createChapterAudio, dialogueVoiceAllowed } from '../chapter-audio.js';
const read = name => JSON.parse(fs.readFileSync(new URL('../'+name,import.meta.url),'utf8'));
const supplied = read('все выровы с 0-3 главы.json'), prior = supplied.canon;
const scripts = Object.assign({},...['scripts','chapter1-scripts','chapter2-scripts','chapter3-scripts','chapter4-scripts'].map(n=>read('assets/'+n+'.json')));
const characters = Object.assign({},read('assets/config.json').characters,...[1,2,3,4].map(n=>read('assets/chapter'+n+'-art.json').characters || {}));
const resources={scripts,characters,language:'russian'}, clone=x=>JSON.parse(JSON.stringify(x));
const routes=[];
function play(picks) {
 const engine = new StoryEngine(resources);let canon=clone(prior),steps=0,seen=[],spoken=[];
 const project=()=>{
  const snap=engine.snapshot();
  canon=createStoryEnvelope({choices:{...canon.choices,...choicesFromSnapshot(snap)},currentChapter:4,progress:{...canon.progress,4:progressFromSnapshot(snap)}},STORY_REGISTRY).canon;
  const projected=reconcileSnapshot(snap,canon);engine.state.flags=projected.flags;engine.state.inventory=projected.inventory;
 };
 engine.start(CHAPTERS[4].start,{flags:seedChapterFlags(canon,4),inventory:seedChapterInventory(canon,4)});project();
 while(engine.state.phase!=='credits' && steps++<2500){
  if(!seen.includes(engine.state.script))seen.push(engine.state.script);
  if(engine.state.phase==='dialogue')spoken.push(engine.state.text);
  if(engine.state.phase==='choice')engine.choose(picks[engine.state.script]);else engine.advance();
  project();
 }
 assert.equal(engine.state.phase,'credits',JSON.stringify(engine.state));
 assert.equal(engine.state.script,'chapter_4/road');
 return {canon,snapshot:engine.snapshot(),seen,spoken};
}
test('Chapter 4 extends the registry and imports the actual completed 0–3 path',()=>{
 assert.deepEqual(CHAPTER_IDS,[0,1,2,3,4]);assert.equal(CHAPTERS[3].nextChapter.id,4);
 assert.equal(chapterLanguage(4,'english'),'russian');assert.equal(chapterForSnapshot({version:1,script:'chapter_4/start'}),4);
 const map=new Map();const service=createStoryStateService({registry:STORY_REGISTRY,storage:{get:k=>map.get(k),set:(k,v)=>{map.set(k,v);return true;}}});
 service.init();service.importSave(JSON.stringify(supplied));assert.deepEqual(service.getCanon().choices,prior.choices);
 assert.equal(service.getCanon().progress[3].completed,true);assert.equal(service.getCanon().progress[4],undefined);
 assert.equal(seedChapterFlags(service.getCanon(),4).monster,'Wendigo');assert.deepEqual(seedChapterInventory(prior,4),['journal_3']);
});
test('all 27 routes reach the same resolution, preserve earlier decisions and retain distinct consequences',()=>{
 for(let a=0;a<3;a++)for(let b=0;b<3;b++)for(let c=0;c<3;c++){
  const r=play({'chapter_4/start':a,'chapter_4/search':b,'chapter_4/rendezvous':c});routes.push(r);
  for(const [key,value] of Object.entries(prior.choices))assert.equal(r.canon.choices[key],value);
  assert.equal(r.canon.derived.quests.wendy_forest_object.value,'resolved');
  assert.equal(r.snapshot.flags.ch4_amulet_returned,true);assert.equal(r.canon.derived.relationships.pacifica_gideon.total,5);
  assert.equal(r.canon.derived.relationships.wendy_respect.total,2+Number(a===1)+Number(b===2));
  assert.equal(!!r.snapshot.flags.ch4_wrist_strain,c===1);assert.equal(!!r.snapshot.flags.ch4_bag_guarded,a===0);
  assert.equal(r.seen.length,12);assert.equal(r.snapshot.language,'russian');assert.equal(r.snapshot.inventory.includes('ch3_wooden_weight'),false);
  const campaign=markCompleted(null,r.snapshot);assert.equal(campaign.chapters[4].completed,true);assert.equal(validCampaign(campaign),true);assert.deepEqual(readCampaign(campaign),campaign);
 }
 const encountered=new Set(routes.flatMap(r=>r.seen));assert.equal(encountered.size,18);
});
test('Chapter 4 save/load, canonical map jumps, alternatives and rewrites use existing state systems',()=>{
 const final=routes[13];const data=new Map();const service=createStoryStateService({registry:STORY_REGISTRY,storage:{get:k=>data.get(k),set:(k,v)=>{data.set(k,clone(v));return true;}}});
 service.init(createStoryEnvelope({canon:final.canon,snapshots:{4:final.snapshot}},STORY_REGISTRY));
 const exported=service.exportSave();service.importSave(JSON.stringify(exported));assert.deepEqual(service.getCanon(),final.canon);
 for(const node of getFlowGraph(4).nodes){const snap=createCanonicalFlowJump({...resources,chapter:4,nodeId:node.id,canon:final.canon});assert.equal(snap.script,'chapter_4/'+node.id);assert.equal(snap.language,'russian');}
 const timeline=buildCanonTimeline(final.canon);assert.ok(timeline.edges.some(e=>e.chapterTransition&&e.from==='3:night_gate'&&e.to==='4:start'));
 service.createAlternativeSession({canon:routes[0].canon,snapshots:{4:routes[0].snapshot}});assert.deepEqual(service.exportSave().canon,exported.canon);service.exitAlternative();
 service.rewriteCanonFrom('ch4.search_method','Terrain',{prepare(candidate,old){Object.assign(candidate,rebuildSnapshotsForRewrite(candidate,old,resources));}});
 assert.equal(service.getChoice('ch4.rescue_plan'),'Anchor');assert.equal(service.getCanon().derived.quests.wendy_forest_object.value,'resolved');
 service.rewriteCanonFrom('ch4.rescue_plan','Signal',{prepare(candidate,old){Object.assign(candidate,rebuildSnapshotsForRewrite(candidate,old,resources));}});
 assert.equal(service.getCanon().derived.flags.ch4_wrist_strain,undefined);assert.equal(service.getState().snapshots[4].flags.ch4_wrist_strain,false);
 assert.equal(service.getChoice('ch3.exit_plan'),'HoldGate');assert.equal(service.validate().valid,true);
});
test('Russian-only resources, scale, acting and voice references resolve without unrelated dialogue playback',()=>{
 const chapter=read('assets/chapter4-scripts.json'),report=read('assets/chapter4-build-report.json'),plan=read('assets/chapter4-voice-plan.json');
 assert.equal(report.scenes,9);assert.equal(report.choices,3);assert.ok(report.counts.russian.words>=5500&&report.counts.russian.words<=6500);
 assert.equal(Object.keys(chapter).length,18);assert.ok(Object.keys(chapter).every(k=>k.startsWith('textes/russian/chapter_4/')));
 const raw=Object.values(chapter).join('\n');assert.doesNotMatch(raw,/\b(?:Will|Mabel|Dipper)\b(?! )|Уилл|Глифул|символ|автор Дневник/i);
 // Hiding prior cast is a reset, not a story connection. No new voice command is authored.
 assert.doesNotMatch(raw,/\[voice /);assert.ok((raw.match(/\[anim /g)||[]).length>=25);assert.ok((raw.match(/\[expression /g)||[]).length>=60);
 const selections=read('assets/selected-voices/manifest.json');assert.equal(selections.voices.length,36);
 for(const ref of selections.voices){const file=fs.readFileSync(new URL('../'+ref.path,import.meta.url));assert.equal(createHash('sha256').update(file).digest('hex'),ref.sha256);}
 assert.ok(selections.voices.find(v=>v.characterId==='Gideon').path.includes('gideon9'));
 for(const slot of plan.lines){const source=chapter['textes/russian/'+slot.script].split('\n').filter(Boolean)[slot.sourceLine];assert.ok(source.includes(slot.text));assert.ok(selections.voices.some(r=>r.path===slot.selectedReference&&r.sha256===slot.referenceSha256));}
 const audio=createChapterAudio({environment:{Audio:class{},SpeechSynthesisUtterance:class{},speechSynthesis:{speak(){throw Error('Unapproved system voice');},cancel(){}}}});audio.setSpeechEnabled(true);
 assert.equal(audio.speechMode({chapter:4,language:'russian'}),'pending');assert.equal(audio.speak({text:'Проверка',chapter:4,language:'russian'}),false);assert.equal(dialogueVoiceAllowed({script:'textes/russian/chapter_4/start'}),false);
});
